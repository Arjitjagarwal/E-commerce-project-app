package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Products;
import com.example.demo.repository.AppRepository;
import com.example.demo.service.AppService;

@CrossOrigin("*")
@RestController
@RequestMapping("/products")
public class AppController {

    private final AppRepository appRepository;

    @Autowired
    private AppService service;

    AppController(AppRepository appRepository) {
        this.appRepository = appRepository;
    }
    
    @GetMapping("/all")
    public List<Products> getall()
    {
    	return appRepository.findAll();
    }

    // GET product by ID
    @GetMapping("/{id}")
    public Products getProduct(@PathVariable Integer id) {
        return service.getProduct(id);
    }

    // GET products by category
    @GetMapping("/category/{category}")
    public List<Products> getByCategory(@PathVariable String category) {
        return service.getProductByCategory(category);
    }

    // ADD new product
    @PostMapping("/addnew")
    public String addProduct(@RequestBody Products product) {
        service.addProduct(product);
        return "Product Added";
    }
}

