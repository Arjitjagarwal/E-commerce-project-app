package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Products;
import com.example.demo.repository.AppRepository;

@Service
public class AppService {

    @Autowired
    private AppRepository repo;

    public Products getProduct(Integer id) {
        return repo.findById(id).orElse(null);
    }

    public List<Products> getProductByCategory(String category) {
        return repo.findByCategory(category);
    }
    
    public Products addProduct(Products product) {
        return repo.save(product);
    }

}

